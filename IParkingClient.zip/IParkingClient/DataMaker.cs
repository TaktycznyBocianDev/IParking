﻿using Dapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace IParkingClient
{
    public class DataMaker
    {


        private readonly IDbConnection _connection;

        public DataMaker(IDbConnection connection)
        {
            _connection = connection;
        }

        public void CreateUser(UserModel user)
        {
            try
            {
                _connection.Open();

                using (var transaction = _connection.BeginTransaction())
                {
                    string query = "INSERT INTO User (UserName, Email, Password, UserTyoe) VALUES (@UserName, @Email, @Password, @UserType);";
                    _connection.Execute(query, new
                    {
                        UserName = user.UserName,
                        Email = user.Email,
                        Password = user.Password,
                        UserType = user.UserType

                    }, transaction: transaction);
                    transaction.Commit();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                throw;
            }
            finally
            {
                _connection.Close();
            }
        }

    }
}
